create trigger noempty
  before INSERT
  on user
  for each row
  begin
    if new.name = '' then
      signal sqlstate '45000';
    end if;
  end;

